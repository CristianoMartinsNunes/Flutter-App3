package com.example.app2_joken_po

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
