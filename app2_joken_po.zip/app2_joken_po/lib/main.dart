import 'package:app2_joken_po/Jogo.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Jogo(),
    debugShowCheckedModeBanner: false,
  ));
}
